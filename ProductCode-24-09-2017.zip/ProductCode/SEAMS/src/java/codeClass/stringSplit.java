/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeClass;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

/* 
    Document   : body
    Created on : Sep 22, 2017, 12:15:28 PM
    Author     : Lankarathne
 */
public class stringSplit {

    public static String split(File fileN) throws IOException {

        String name = FileUtils.readFileToString(fileN, "UTF-8");
        
        String[] SpFile = name.split("\\");
        String FileName = SpFile[2];
        
        //Pass values
        return FileName;

    }

}
