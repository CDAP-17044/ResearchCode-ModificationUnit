package codeClass;

import java.io.File;
import java.io.FileFilter;

/* 
    Document   : body
    Created on : Sep 22, 2017, 12:15:28 PM
    Author     : Lankarathne
 */
public class CodeModification {

    public static File lastFileModified() {
        String filepath = "C:\\temp\\";
        File fl = new File(filepath);
        File[] files = fl.listFiles(new FileFilter() {
            public boolean accept(File file) {
                return file.isFile();
            }
        });
        long lastMod = Long.MIN_VALUE;
        File choice = null;
        for (File file : files) {
            if (file.lastModified() > lastMod) {
                choice = file;
                lastMod = file.lastModified();
            }
        }
        return choice;
    }

}
