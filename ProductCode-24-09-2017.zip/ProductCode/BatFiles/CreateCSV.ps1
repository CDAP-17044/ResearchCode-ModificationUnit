$Time = Get-Content 'C:\InputFiles\TIME.txt'
$Current = Get-Content 'C:\InputFiles\CUR.txt'
$volt = Get-Content 'C:\InputFiles\VOLT.txt'

$excel = New-Object -ComObject excel.application
$excel.visible = $False
$workbook = $excel.Workbooks.Add()
$diskSpacewksht= $workbook.Worksheets.Item(1)

#$diskSpacewksht.Cells.Item(1,1) = 'Time'
#$diskSpacewksht.Cells.Item(1,2) = 'Current'
#$diskSpacewksht.Cells.Item(1,3) = 'Volt'
#$diskSpacewksht.Cells.Item(1,4) = 'Code Segments'

#$diskSpacewksht.Cells.Item(2,8).Font.Size = 18
#$diskSpacewksht.Cells.Item(2,8).Font.Bold=$True
#$diskSpacewksht.Cells.Item(2,8).Font.Name = "Cambria"
#$diskSpacewksht.Cells.Item(2,8).Font.ThemeFont = 1
#$diskSpacewksht.Cells.Item(2,8).Font.ThemeColor = 4
#$diskSpacewksht.Cells.Item(2,8).Font.ColorIndex = 55
#$diskSpacewksht.Cells.Item(2,8).Font.Color = 8210719

$row = 1
$col1 = 1
$col2 = 1

	foreach ($timeVal in $Time){

		$diskSpacewksht.Cells.Item($row,1) = $timeVal
		$row++

	}

	foreach ($currentVal in $Current){

		$diskSpacewksht.Cells.Item($col1,2) = $currentVal
		$col1++

	}

	foreach ($voltVal in $volt){

		$diskSpacewksht.Cells.Item($col2,3) = $voltVal
		$col2++

	}

$excel.DisplayAlerts = 'False'
$ext=".CSV"
$path="C:\CSVfiles\DataSet$ext"
$workbook.SaveAs($path) 
$workbook.Close
$excel.DisplayAlerts = 'False'
$excel.Quit()