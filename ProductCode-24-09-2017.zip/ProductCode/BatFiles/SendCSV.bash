#! /bin/bash
scp /C/CSVfiles/DataSet.csv ubuntu@184.73.132.39:.