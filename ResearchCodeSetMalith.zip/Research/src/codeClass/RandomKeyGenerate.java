/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeClass;

/**
 *
 * @author Lankarathne
 */
public class RandomKeyGenerate {
    
    public static int cubed(int num){
    
        int cubVal = num*num*num;
        return cubVal;
    
    }
    
}
