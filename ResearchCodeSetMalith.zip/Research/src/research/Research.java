
package research;

import codeClass.FindTheLanguage;
import java.util.Scanner;
import java.io.*;
import java.util.Date;
import codeClass.RandomKeyGenerate;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 *
 * @author Lankarathne
 */
public class Research {

   
    public static void main(String[] args) throws IOException {
        
        //Variable Declaration
        Scanner scn = new Scanner(System.in);
        BufferedReader br = null;
        BufferedWriter bw = null;
        FileWriter fw = null;
        String line ;
        
        //Get Date and time
        int i = (int)(new Date().getTime());
        System.out.println(i);
        
        //Random Key Generation
        int randomKey = 0;
        randomKey = RandomKeyGenerate.cubed(i);
        System.out.println(randomKey);
        
        //Find The Programming language That Algorithum Written
        System.out.println("Enter the File Name : ");
        String fileName = scn.next();
        System.out.println(FindTheLanguage.language(fileName));
        
        try {
        
            Path pth= Paths.get("C:\\Users\\Lankarathne\\Desktop\\code\\"+ fileName);
            List<String> lines = Files.readAllLines(pth,StandardCharsets.UTF_8);
            
            //Set the Line number to write 
            int position = 22;
            
            //Declare the content that going to be insert
            String breakePattern  = "int = "+randomKey+"*"+randomKey+"";
            
            //Insert the Content to the Algorithum
            lines.add(position, breakePattern);
            Files.write(pth, lines, StandardCharsets.UTF_8);
            
            System.out.println("Successfully Write the Content");
            
        }catch (FileNotFoundException fn){
        
            System.out.println(fn.getMessage() + "The File was Not Found");
            System.exit(0);
            
        }
        
        try{
        
            //Read the programe 
            while ((line = br.readLine()) != null){
            
                System.out.println(line);
            
            }
        
        }catch(IOException ioe){
        
            System.out.println(ioe.getMessage()+"Error While Reading");
        
        }finally{
        
            System.exit(0);
            
        }
        
    }
    
}
