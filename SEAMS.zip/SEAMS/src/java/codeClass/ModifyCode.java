/*
    Document   : upload
    Created on : Sep 22, 2017, 11:48:20 PM
    Author     : Lankarathne
-*/
package codeClass;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lankarathne
 */
public class ModifyCode extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            if (request.getParameter("startModify") != null) {

                CodeModification fn = new CodeModification();

                //Get the file path to File Type variable
                File fileName = fn.lastFileModified();

                //Convert the File Name to String
                String p = fileName.toString();
                String arr[] = p.split("\\\\");

                //Get the File Name 
                String filName = arr[2].toString();
                out.println("<h4>File Name :" + filName + "</h4>");

                //Find the Language Algorithm Written 
                String Lan = languageFind.language(filName);
                out.println("<h4>The Algorithm Written Lanuage : " + Lan + "</h4>");

                //Get the File Path
                Path pth = Paths.get("C:\\temp\\" + filName);

                List<String> lines = Files.readAllLines(pth, StandardCharsets.UTF_8);

                //Set the Line number to write 
                int position = 22;

                //Get the RandomKey
                RandomKeyGenerate key = new RandomKeyGenerate();
                int ky = key.GetKey();

                //Declare the content that going to be insert
                String breakePattern = "int = " + ky + "*" + ky + "";

                //Insert the Content to the Algorithum
                lines.add(position, breakePattern);
                Files.write(pth, lines, StandardCharsets.UTF_8);
                
                out.println("Successfully Write the Content");
                
                out.print("<p>To Go To Home Page Click <a href='index.jsp'>Continue</a><p>");

            }

        } catch (Exception e) {

        } finally {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
