/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeClass;

/**
 *
 * @author Lankarathne
 */
public class FindTheLanguage {
    
    public static String language(String lan){
    
        String ProgrammingLan = null;
        
        //Get the Extention
        String ext = lan.substring(lan.lastIndexOf(".")+1);
        
        //Find the language using extention
        if (("c".equals(ext)) || ("cc".equals(ext))){
        
            ProgrammingLan = "Objective-C";
            
        }else if ("java".equals(ext)){
        
            ProgrammingLan = "JAVA";
        
        }else if ("cpp".equals(ext)){
        
            ProgrammingLan = "C++";
        
        }else if ("cs".equals(ext)){
        
            ProgrammingLan = "C#";
        
        }else if ("txt".equals(ext)){
        
            ProgrammingLan = "TEXT File";
        
        }else {
        
            ProgrammingLan = "Language Not Identified";
        
        }
        
        return ProgrammingLan;
    
    }
    
}
