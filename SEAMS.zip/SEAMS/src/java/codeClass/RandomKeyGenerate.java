package codeClass;

import static java.lang.System.out;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lankarathne
 */
public class RandomKeyGenerate {
    
    public int GetKey(){
        float ctm,Fkey,Fval;
        int key;
        Date dt = new Date();
        SimpleDateFormat ft = new SimpleDateFormat ("hhmmssSSS");
        int fdt = Integer.parseInt(ft.format(dt));
        ctm = (float ) fdt;
        Fval = (((ctm*ctm)*(ctm*ctm))/ctm)+ctm;
        Fkey = Fval%10000000;
        
        key = Math.round(Fkey);
        
        return key;
    
    }
                        
    
}
